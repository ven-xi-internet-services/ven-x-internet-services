// Copyright (c) 2015 The Brick Authors.

#include "brick/event/event_bus.h"

// Declare the static instance since this can't be done in the header file
EventBus* EventBus::instance = nullptr;

