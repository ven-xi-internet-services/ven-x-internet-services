// Copyright (c) 2015 The Brick Authors.

#ifndef BRICK_EVENT_EVENT_SENDER_H_
#define BRICK_EVENT_EVENT_SENDER_H_
#pragma once

class EventSender {

};

#endif  // BRICK_EVENT_EVENT_SENDER_H_
